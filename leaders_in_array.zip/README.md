# Leaders in an Array

## Problem Statement
You are given an integer array `arr` of size `n`.  
An element is considered a leader if it is greater than all the elements to its right.  
Your task is to find all such leader elements in the array.

### Example
Input:
```
arr = [16, 17, 4, 3, 5, 2]
```
Output:
```
Leaders: [17, 5, 2]
```

## Run the code
```bash
python leaders.py
```
